"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Loader2, Filter } from "lucide-react"
import { AnimatePresence, motion } from "framer-motion"
import { cn } from "@/lib/utils"
import RestaurantCard from "./restaurant-card"
import { useMobile } from "@/hooks/use-mobile"
import FilterMenu from "./filter-menu"
import type { Cuisine, PriceRange, SortOption } from "@/types/restaurant"
import ReactMarkdown from "react-markdown"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  restaurants?: Restaurant[]
}

type Restaurant = {
  id?: string
  name: string
  cuisine: string
  location: string
  city?: string
  rating: number
  priceRange: string
  image: string
  phone?: string
  hours?: string
  website?: string
  description?: string
  specialties?: string[]
  vegetarian?: boolean
}

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [initialLoading, setInitialLoading] = useState(true)
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({
    cuisines: [] as Cuisine[],
    priceRanges: [] as PriceRange[],
    sortBy: "rating" as SortOption,
  })
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const isMobile = useMobile()

  // Get initial greeting from Gemini
  useEffect(() => {
    const getInitialGreeting = async () => {
      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: "initial greeting",
            history: [],
            isInitialGreeting: true,
          }),
        })

        if (!response.ok) {
          throw new Error("Failed to fetch initial greeting")
        }

        const data = await response.json()

        setMessages([
          {
            id: "1",
            content: data.text,
            role: "assistant",
            restaurants: data.restaurants || [],
          },
        ])
      } catch (error) {
        console.error("Error fetching initial greeting:", error)
        setMessages([
          {
            id: "1",
            content:
              "Hello! I can help you find restaurants in India based on cuisine. What type of food are you craving today?",
            role: "assistant",
          },
        ])
      } finally {
        setInitialLoading(false)
      }
    }

    getInitialGreeting()
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: input,
          history: messages.map((m) => ({ role: m.role, content: m.content })),
          filters,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to fetch response")
      }

      const data = await response.json()

      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          content: data.text,
          role: "assistant",
          restaurants: data.restaurants || [],
        },
      ])
    } catch (error) {
      console.error("Error:", error)
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          content: "Sorry, I encountered an error. Please try again.",
          role: "assistant",
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const toggleFilters = () => {
    setShowFilters(!showFilters)
  }

  const applyFilters = (newFilters: typeof filters) => {
    setFilters(newFilters)
    setShowFilters(false)
  }

  return (
    <div className="flex h-[80vh] w-full max-w-4xl flex-col rounded-xl bg-white/90 backdrop-blur-sm shadow-xl dark:bg-gray-800/80">
      <div className="flex items-center justify-between border-b border-gray-200 p-4 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Restaurant Chat</h2>
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleFilters}
          className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100"
        >
          <Filter size={20} />
          <span className="sr-only">Filter</span>
        </Button>
      </div>

      {showFilters && <FilterMenu filters={filters} onApply={applyFilters} onClose={() => setShowFilters(false)} />}

      <div className="flex-1 overflow-y-auto p-4">
        {initialLoading ? (
          <div className="flex h-full items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-[#E94057]" />
            <span className="ml-2 text-gray-800 dark:text-gray-200">Loading Gemini AI...</span>
          </div>
        ) : (
          <AnimatePresence initial={false}>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className={cn("mb-4 flex", message.role === "user" ? "justify-end" : "justify-start")}
              >
                <div
                  className={cn(
                    "max-w-[80%] rounded-xl p-4",
                    message.role === "user"
                      ? "bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] text-white"
                      : "bg-gray-100 dark:bg-gray-700",
                  )}
                >
                  {message.role === "user" ? (
                    <p className="whitespace-pre-wrap text-white">{message.content}</p>
                  ) : (
                    <div className="prose prose-sm dark:prose-invert max-w-none text-gray-900 dark:text-white">
                      <ReactMarkdown>{message.content}</ReactMarkdown>
                    </div>
                  )}

                  {message.restaurants && message.restaurants.length > 0 && (
                    <div className="mt-4 grid gap-4 sm:grid-cols-2">
                      {message.restaurants.map((restaurant, index) => (
                        <RestaurantCard key={index} restaurant={restaurant} index={index} />
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 flex justify-start"
              >
                <div className="flex max-w-[80%] items-center space-x-2 rounded-xl bg-gray-100 p-4 dark:bg-gray-700">
                  <Loader2 className="h-4 w-4 animate-spin text-[#E94057] dark:text-[#E94057]" />
                  <p className="text-sm text-gray-900 dark:text-white">Searching for restaurants with Gemini AI...</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about any cuisine in India..."
            className="flex-1 border-0 bg-gray-100/50 text-gray-900 focus-visible:ring-1 focus-visible:ring-[#E94057] dark:bg-gray-700/50 dark:text-white"
            disabled={isLoading || initialLoading}
          />
          <Button
            type="submit"
            size="icon"
            disabled={isLoading || initialLoading || !input.trim()}
            className="bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] hover:opacity-90"
          >
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </form>
    </div>
  )
}


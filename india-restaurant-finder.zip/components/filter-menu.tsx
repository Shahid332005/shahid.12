"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { X } from "lucide-react"
import { motion } from "framer-motion"
import type { Cuisine, PriceRange, SortOption } from "@/types/restaurant"

interface FilterMenuProps {
  filters: {
    cuisines: Cuisine[]
    priceRanges: PriceRange[]
    sortBy: SortOption
  }
  onApply: (filters: FilterMenuProps["filters"]) => void
  onClose: () => void
}

export default function FilterMenu({ filters, onApply, onClose }: FilterMenuProps) {
  const [localFilters, setLocalFilters] = useState(filters)

  const cuisineOptions: Cuisine[] = [
    "North Indian",
    "South Indian",
    "Mughlai",
    "Bengali",
    "Gujarati",
    "Punjabi",
    "Rajasthani",
    "Goan",
    "Hyderabadi",
    "Modern Indian",
  ]

  const priceOptions: PriceRange[] = ["₹", "₹₹", "₹₹₹", "₹₹₹₹"]

  const sortOptions: { value: SortOption; label: string }[] = [
    { value: "rating", label: "Rating (High to Low)" },
    { value: "priceAsc", label: "Price (Low to High)" },
    { value: "priceDesc", label: "Price (High to Low)" },
  ]

  const handleCuisineChange = (cuisine: Cuisine, checked: boolean) => {
    setLocalFilters((prev) => ({
      ...prev,
      cuisines: checked ? [...prev.cuisines, cuisine] : prev.cuisines.filter((c) => c !== cuisine),
    }))
  }

  const handlePriceChange = (price: PriceRange, checked: boolean) => {
    setLocalFilters((prev) => ({
      ...prev,
      priceRanges: checked ? [...prev.priceRanges, price] : prev.priceRanges.filter((p) => p !== price),
    }))
  }

  const handleSortChange = (value: SortOption) => {
    setLocalFilters((prev) => ({
      ...prev,
      sortBy: value,
    }))
  }

  const handleApply = () => {
    onApply(localFilters)
  }

  const handleReset = () => {
    setLocalFilters({
      cuisines: [],
      priceRanges: [],
      sortBy: "rating",
    })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="border-b border-gray-200 bg-white p-4 dark:border-gray-700 dark:bg-gray-800"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">Filters</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X size={18} />
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div>
          <h4 className="mb-2 font-medium text-gray-900 dark:text-white">Cuisine</h4>
          <div className="space-y-2">
            {cuisineOptions.map((cuisine) => (
              <div key={cuisine} className="flex items-center space-x-2">
                <Checkbox
                  id={`cuisine-${cuisine}`}
                  checked={localFilters.cuisines.includes(cuisine)}
                  onCheckedChange={(checked) => handleCuisineChange(cuisine, checked as boolean)}
                />
                <Label htmlFor={`cuisine-${cuisine}`} className="text-gray-800 dark:text-gray-200">
                  {cuisine}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="mb-2 font-medium text-gray-900 dark:text-white">Price Range</h4>
          <div className="space-y-2">
            {priceOptions.map((price) => (
              <div key={price} className="flex items-center space-x-2">
                <Checkbox
                  id={`price-${price}`}
                  checked={localFilters.priceRanges.includes(price)}
                  onCheckedChange={(checked) => handlePriceChange(price, checked as boolean)}
                />
                <Label htmlFor={`price-${price}`} className="text-gray-800 dark:text-gray-200">
                  {price}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="mb-2 font-medium text-gray-900 dark:text-white">Sort By</h4>
          <RadioGroup value={localFilters.sortBy} onValueChange={(value) => handleSortChange(value as SortOption)}>
            {sortOptions.map((option) => (
              <div key={option.value} className="flex items-center space-x-2">
                <RadioGroupItem value={option.value} id={`sort-${option.value}`} />
                <Label htmlFor={`sort-${option.value}`} className="text-gray-800 dark:text-gray-200">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      </div>

      <div className="mt-6 flex justify-end space-x-2">
        <Button variant="outline" onClick={handleReset}>
          Reset
        </Button>
        <Button
          onClick={handleApply}
          className="bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] hover:opacity-90"
        >
          Apply Filters
        </Button>
      </div>
    </motion.div>
  )
}


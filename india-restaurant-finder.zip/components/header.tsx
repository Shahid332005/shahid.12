"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { MoonIcon, SunIcon, Menu, X } from "lucide-react"
import { useTheme } from "next-themes"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"

export default function Header() {
  const { theme, setTheme } = useTheme()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 border-b border-gray-200 bg-white/80 backdrop-blur-md dark:border-gray-800 dark:bg-gray-900/80">
      <div className="container flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] bg-clip-text text-xl font-bold text-transparent">
            IndiaEats
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-6 md:flex">
          <Link
            href="/"
            className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
          >
            Home
          </Link>
          <Link
            href="/cuisines"
            className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
          >
            Cuisines
          </Link>
          <Link
            href="/cities"
            className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
          >
            Cities
          </Link>
          <Link
            href="/about"
            className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
          >
            About
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full">
            {theme === "dark" ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />}
            <span className="sr-only">Toggle theme</span>
          </Button>

          {/* Mobile Menu Button */}
          <Button variant="ghost" size="icon" onClick={toggleMenu} className="md:hidden">
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            <span className="sr-only">Toggle menu</span>
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden"
          >
            <nav className="flex flex-col space-y-4 p-4">
              <Link
                href="/"
                className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/cuisines"
                className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
                onClick={() => setIsMenuOpen(false)}
              >
                Cuisines
              </Link>
              <Link
                href="/cities"
                className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
                onClick={() => setIsMenuOpen(false)}
              >
                Cities
              </Link>
              <Link
                href="/about"
                className="text-sm font-medium text-gray-700 transition-colors hover:text-[#E94057] dark:text-gray-300 dark:hover:text-[#E94057]"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}


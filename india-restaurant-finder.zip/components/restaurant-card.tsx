"use client"

import type React from "react"
import Image from "next/image"
import { MapPin, Star, Phone, Clock, ExternalLink, Heart } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

type RestaurantCardProps = {
  restaurant: {
    id?: string
    name: string
    cuisine: string
    location: string
    city?: string
    rating: number
    priceRange: string
    image: string
    phone?: string
    hours?: string
    website?: string
    description?: string
    specialties?: string[]
    vegetarian?: boolean
  }
  index: number
}

export default function RestaurantCard({ restaurant, index }: RestaurantCardProps) {
  const [isFavorite, setIsFavorite] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsFavorite(!isFavorite)
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: index * 0.1 }}
        className="group overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800"
        onClick={() => setShowDetails(true)}
      >
        <div className="relative h-40 w-full overflow-hidden">
          <Image
            src={
              restaurant.image || `/placeholder.svg?height=160&width=320&text=${encodeURIComponent(restaurant.name)}`
            }
            alt={restaurant.name}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-110"
          />
          <Button
            variant="ghost"
            size="icon"
            className={`absolute right-2 top-2 rounded-full bg-white/80 p-1 backdrop-blur-sm ${
              isFavorite ? "text-red-500" : "text-gray-600"
            }`}
            onClick={toggleFavorite}
          >
            <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />
          </Button>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
            <div className="flex items-center gap-1">
              <Star size={14} className="text-yellow-400" />
              <span className="text-sm font-medium text-white">{restaurant.rating}</span>
              <span className="text-xs text-white/80">• {restaurant.priceRange}</span>
            </div>
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-bold text-gray-900 dark:text-white">{restaurant.name}</h3>
          <p className="text-sm text-gray-800 dark:text-gray-200">{restaurant.cuisine}</p>

          <div className="mt-2 flex items-center gap-1">
            <MapPin size={14} className="text-gray-500" />
            <span className="truncate text-xs text-gray-800 dark:text-gray-200">{restaurant.location}</span>
          </div>

          <Button
            variant="link"
            size="sm"
            className="mt-1 h-auto p-0 text-[#E94057]"
            onClick={() => setShowDetails(true)}
          >
            View Details
          </Button>
        </div>
      </motion.div>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{restaurant.name}</DialogTitle>
            <DialogDescription>{restaurant.cuisine}</DialogDescription>
          </DialogHeader>

          <div className="relative h-48 w-full overflow-hidden rounded-md">
            <Image
              src={
                restaurant.image || `/placeholder.svg?height=160&width=320&text=${encodeURIComponent(restaurant.name)}`
              }
              alt={restaurant.name}
              fill
              className="object-cover"
            />
            <div className="absolute bottom-2 right-2 rounded-full bg-white/90 px-2 py-1 backdrop-blur-sm">
              <div className="flex items-center gap-1">
                <Star size={16} className="text-yellow-500" />
                <span className="text-sm font-medium">{restaurant.rating}</span>
              </div>
            </div>
          </div>

          <div className="grid gap-3">
            <div className="flex items-start gap-2">
              <MapPin size={18} className="mt-0.5 text-gray-500" />
              <span className="text-sm text-gray-700 dark:text-gray-300">{restaurant.location}</span>
            </div>

            <div className="flex items-center gap-2">
              <Star size={18} className="text-yellow-500" />
              <span className="text-sm text-gray-700 dark:text-gray-300">
                {restaurant.rating} • {restaurant.priceRange}
              </span>
            </div>

            {restaurant.phone && (
              <div className="flex items-center gap-2">
                <Phone size={18} className="text-gray-500" />
                <span className="text-sm text-gray-700 dark:text-gray-300">{restaurant.phone}</span>
              </div>
            )}

            {restaurant.hours && (
              <div className="flex items-center gap-2">
                <Clock size={18} className="text-gray-500" />
                <span className="text-sm text-gray-700 dark:text-gray-300">{restaurant.hours}</span>
              </div>
            )}

            {restaurant.description && (
              <div className="mt-2">
                <p className="text-sm text-gray-700 dark:text-gray-300">{restaurant.description}</p>
              </div>
            )}

            {restaurant.specialties && restaurant.specialties.length > 0 && (
              <div className="mt-2">
                <h4 className="mb-1 text-sm font-medium text-gray-900 dark:text-white">Specialties:</h4>
                <div className="flex flex-wrap gap-1">
                  {restaurant.specialties.map((specialty, i) => (
                    <span
                      key={i}
                      className="rounded-full bg-orange-100 px-2 py-1 text-xs text-orange-800 dark:bg-orange-900/30 dark:text-orange-300"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setIsFavorite(!isFavorite)}
              className={isFavorite ? "text-red-500" : ""}
            >
              <Heart size={16} className="mr-2" fill={isFavorite ? "currentColor" : "none"} />
              {isFavorite ? "Saved" : "Save"}
            </Button>

            {restaurant.website && (
              <Button
                className="bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] hover:opacity-90"
                onClick={() => window.open(restaurant.website, "_blank")}
              >
                <ExternalLink size={16} className="mr-2" />
                Visit Website
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}


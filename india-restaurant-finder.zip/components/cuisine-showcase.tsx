"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const cuisines = [
  {
    name: "North Indian",
    image: "/placeholder.svg?height=300&width=400&text=North+Indian",
    description: "Rich, creamy curries with bread varieties like naan and roti.",
  },
  {
    name: "South Indian",
    image: "/placeholder.svg?height=300&width=400&text=South+Indian",
    description: "Rice-based dishes with coconut, tamarind, and curry leaves.",
  },
  {
    name: "Mughlai",
    image: "/placeholder.svg?height=300&width=400&text=Mughlai",
    description: "Aromatic, rich dishes with nuts, dried fruits, and saffron.",
  },
  {
    name: "Bengali",
    image: "/placeholder.svg?height=300&width=400&text=Bengali",
    description: "Fish curries, mustard, and sweet dishes like rasgulla.",
  },
  {
    name: "Gujarati",
    image: "/placeholder.svg?height=300&width=400&text=Gujarati",
    description: "Vegetarian dishes with a balance of sweet, salty, and spicy.",
  },
  {
    name: "Goan",
    image: "/placeholder.svg?height=300&width=400&text=Goan",
    description: "Seafood, coconut, and vinegar-based dishes with Portuguese influence.",
  },
]

export default function CuisineShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % cuisines.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + cuisines.length) % cuisines.length)
  }

  return (
    <div className="relative mx-auto mt-8 max-w-4xl overflow-hidden rounded-xl bg-white p-4 shadow-lg dark:bg-gray-800">
      <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 dark:text-white">Popular Indian Cuisines</h2>

      <div className="relative h-64 w-full">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="flex h-full items-center justify-center"
        >
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="relative h-48 w-full overflow-hidden rounded-lg">
              <Image
                src={cuisines[currentIndex].image || "/placeholder.svg"}
                alt={cuisines[currentIndex].name}
                fill
                className="object-cover"
              />
            </div>
            <div className="flex flex-col justify-center">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white">{cuisines[currentIndex].name}</h3>
              <p className="mt-2 text-gray-800 dark:text-gray-200">{cuisines[currentIndex].description}</p>
              <Button className="mt-4 bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] hover:opacity-90">
                Explore {cuisines[currentIndex].name} Restaurants
              </Button>
            </div>
          </div>
        </motion.div>

        <Button
          variant="outline"
          size="icon"
          onClick={prevSlide}
          className="absolute left-0 top-1/2 -translate-y-1/2 rounded-full bg-white/80 backdrop-blur-sm dark:bg-gray-800/80"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={nextSlide}
          className="absolute right-0 top-1/2 -translate-y-1/2 rounded-full bg-white/80 backdrop-blur-sm dark:bg-gray-800/80"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="mt-4 flex justify-center space-x-2">
        {cuisines.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 w-2 rounded-full ${
              index === currentIndex
                ? "bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387]"
                : "bg-gray-300 dark:bg-gray-600"
            }`}
          />
        ))}
      </div>
    </div>
  )
}


export type Cuisine =
  | "North Indian"
  | "South Indian"
  | "Mughlai"
  | "Bengali"
  | "Gujarati"
  | "Punjabi"
  | "Rajasthani"
  | "Goan"
  | "Hyderabadi"
  | "Modern Indian"
  | string

export type PriceRange = "₹" | "₹₹" | "₹₹₹" | "₹₹₹₹"

export type SortOption = "rating" | "priceAsc" | "priceDesc"

export interface Restaurant {
  id: string
  name: string
  cuisine: Cuisine
  location: string
  city: string
  rating: number
  priceRange: PriceRange
  image: string
  phone?: string
  hours?: string
  website?: string
  description?: string
  specialties?: string[]
  vegetarian?: boolean
}


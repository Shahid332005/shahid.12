import ChatInterface from "@/components/chat-interface"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/header"

export default function Home() {
  return (
    <ThemeProvider>
      <div className="flex min-h-screen flex-col bg-[#FFF8E8] dark:from-gray-900 dark:to-gray-800">
        <Header />
        <main className="flex-1">
          <div className="container flex flex-col items-center justify-center gap-4 px-4 py-8 md:py-10">
            <h1 className="text-center text-4xl font-extrabold tracking-tight md:text-5xl">
              <span className="bg-gradient-to-r from-[#F05A28] via-[#E94057] to-[#8A2387] bg-clip-text text-transparent">
                India Restaurant Finder
              </span>
            </h1>
            <p className="max-w-[700px] text-center text-gray-900 dark:text-gray-100 md:text-xl">
              Discover the best restaurants in India based on your cuisine preferences
            </p>
            <ChatInterface />
          </div>
        </main>
        <footer className="border-t border-gray-200 bg-white/80 py-6 text-center text-sm text-gray-600 dark:border-gray-800 dark:bg-gray-900/80 dark:text-gray-400">
          <div className="container">
            <p>© {new Date().getFullYear()} India Restaurant Finder. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </ThemeProvider>
  )
}


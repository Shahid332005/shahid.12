import { GoogleGenerativeAI } from "@google/generative-ai"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { message, history, isInitialGreeting } = await req.json()

    // Initialize the Gemini API
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" })

    // Prepare the chat history for Gemini
    const chatHistory =
      history && history.length > 0
        ? history.map((msg: any) => `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`).join("\n")
        : ""

    let prompt = ""

    if (isInitialGreeting) {
      // Initial greeting prompt
      prompt = `
        You are an AI assistant specializing in Indian restaurants and cuisine.
        You help users find restaurants in India based on their preferences.
        
        Generate a friendly, welcoming greeting message for a user who has just opened the India Restaurant Finder app.
        Your greeting should:
        1. Be warm and inviting
        2. Briefly explain that you can help find restaurants based on cuisine, city, or other preferences
        3. Ask the user what they're looking for (e.g., specific cuisine, city, etc.)
        4. Be concise (2-3 sentences maximum)
        
        DO NOT recommend any specific restaurants in this initial greeting.
        DO NOT include any JSON or technical formatting in your response.
      `
    } else {
      // Regular conversation prompt
      prompt = `
        You are an AI assistant specializing in Indian restaurants and cuisine. 
        Help the user find restaurants in India based on their preferences.
        
        Chat history:
        ${chatHistory}
        
        User message: ${message}
        
        You have extensive knowledge about Indian restaurants across all cities in India. When the user asks about restaurants in any city, provide information about actual, well-known restaurants in that location.
        
        FORMAT YOUR RESPONSE EXACTLY LIKE THIS EXAMPLE:
        
        Ah, Agra! The city of the Taj Mahal and equally delightful culinary experiences. Here are a few restaurants that I think you might enjoy:

        1.  **Pinch of Spice:** This is a very popular choice in Agra, known for its delicious North Indian and Mughlai cuisine. They have a wide range of options, a comfortable ambiance, and are generally considered moderately priced.

        2.  **Esphahan (at The Oberoi Amarvilas):** If you're looking for a truly luxurious dining experience with authentic Mughlai flavors, Esphahan is the place to go. It's definitely on the higher end price-wise, but the quality and ambiance are exceptional.

        3.  **Dasaprakash:** Craving South Indian flavors? Dasaprakash is a great option for dosas, uttapams, and other South Indian specialties. It's a more casual and budget-friendly choice.

        4.  **Agra Food Corner:** Known for delicious street food, especially their chaat items. If you want to try some authentic, local Agra flavors, don't miss it.
        
        IMPORTANT GUIDELINES:
        1. Keep your response concise and to the point (maximum 4-5 sentences introduction, then a numbered list)
        2. Use proper markdown formatting with bold restaurant names
        3. Recommend 2-4 popular restaurants that match their query
        4. Be conversational but brief
        5. If the user asks about a specific cuisine or dietary preference, focus on that
        6. Never say you don't have data about a location
        
        DO NOT include any JSON data or technical formatting in your response.
      `
    }

    // Generate a response from Gemini
    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()

    // Remove any JSON-like content from the response
    const cleanedText = text.replace(/RESTAURANTS_JSON:.*$/s, "").trim()

    // Generate restaurant data separately
    if (!isInitialGreeting) {
      try {
        // Create a separate prompt just for restaurant data
        const dataPrompt = `
          Based on the user message "${message}", generate data for 2-4 popular restaurants in the mentioned location or cuisine.
          
          Return a valid JSON array with this exact format:
          [
            {
              "id": "unique_id",
              "name": "Restaurant Name",
              "cuisine": "cuisine_type",
              "location": "full_address",
              "city": "city_name",
              "rating": 4.5,
              "priceRange": "₹₹",
              "image": "/placeholder.svg?height=160&width=320&text=Restaurant+Name",
              "phone": "+91 1234567890",
              "hours": "11:00 AM - 11:00 PM",
              "website": "https://example.com",
              "description": "brief_description",
              "specialties": ["specialty1", "specialty2"],
              "vegetarian": false
            }
          ]
          
          IMPORTANT: Do NOT include any markdown formatting, code blocks, or explanatory text. Return ONLY the raw JSON array.
          Use simple names without special characters. For null values, use null without quotes.
        `

        const dataResult = await model.generateContent(dataPrompt)
        const dataResponse = await dataResult.response
        let dataText = dataResponse.text()

        // Remove markdown code block formatting if present
        dataText = dataText
          .replace(/^```json\s*/, "")
          .replace(/```\s*$/, "")
          .trim()

        try {
          // Try to parse the JSON data
          const restaurants = JSON.parse(dataText)

          return NextResponse.json({
            text: cleanedText,
            restaurants: restaurants,
          })
        } catch (jsonError) {
          console.error("Error parsing restaurant JSON:", jsonError, "Raw data:", dataText)

          // Generate fallback restaurant data
          const fallbackRestaurants = generateFallbackRestaurants(message)

          return NextResponse.json({
            text: cleanedText,
            restaurants: fallbackRestaurants,
          })
        }
      } catch (dataError) {
        console.error("Error generating restaurant data:", dataError)

        return NextResponse.json({
          text: cleanedText,
          restaurants: [],
        })
      }
    } else {
      // For initial greeting, return empty restaurants array
      return NextResponse.json({
        text: cleanedText,
        restaurants: [],
      })
    }
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json({ error: `Failed to process request: ${error.message}` }, { status: 500 })
  }
}

// Function to generate fallback restaurant data if JSON parsing fails
function generateFallbackRestaurants(message: string) {
  // Extract city name from message (simple approach)
  const cityMatch = message.match(/\b([A-Z][a-z]+)\b/g)
  const city = cityMatch ? cityMatch[0] : "Delhi"

  return [
    {
      id: `${city.toLowerCase()}_1`,
      name: `${city} Restaurant 1`,
      cuisine: "North Indian",
      location: `Main Street, ${city}`,
      city: city,
      rating: 4.3,
      priceRange: "₹₹",
      image: `/placeholder.svg?height=160&width=320&text=${city}+Restaurant+1`,
      phone: "+91 1234567890",
      hours: "11:00 AM - 11:00 PM",
      website: null,
      description: `Popular restaurant in ${city} serving delicious North Indian cuisine.`,
      specialties: ["Butter Chicken", "Naan"],
      vegetarian: false,
    },
    {
      id: `${city.toLowerCase()}_2`,
      name: `${city} Restaurant 2`,
      cuisine: "South Indian",
      location: `Market Road, ${city}`,
      city: city,
      rating: 4.1,
      priceRange: "₹",
      image: `/placeholder.svg?height=160&width=320&text=${city}+Restaurant+2`,
      phone: "+91 9876543210",
      hours: "8:00 AM - 10:00 PM",
      website: null,
      description: `Authentic South Indian restaurant in ${city} known for its dosas and idlis.`,
      specialties: ["Masala Dosa", "Idli Sambhar"],
      vegetarian: true,
    },
  ]
}

